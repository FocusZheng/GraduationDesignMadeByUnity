﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HUDTextParent : MonoBehaviour {

    public static HUDTextParent _instance;
	// Use this for initialization
	void Awake () {
        _instance = this;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
